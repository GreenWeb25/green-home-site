document.addEventListener("DOMContentLoaded", function() {
    console.log("Sito Green Home Solution caricato con successo!");
});